CREATE External TABLE hadoop.Sales (
sale_id INT, 
amount FLOAT)
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
LINES TERMINATED BY '\n' ;


--##shows the table definition
desc vbajaj.sales;


--##Get Entire Metadata
show create table vbajaj.sales;

 --##Check hdfs in shell (new terminal)

 
 hdfs dfs -ls /user/hive/warehouse/vbajaj.db/sales/
 
----##insert data

 insert into table hadoop.sales select *  from (select 1,111.01)a;

 --##Check hdfs in shell (new terminal)
 
  hdfs dfs -ls /user/hive/warehouse/vbajaj.db/sales/
  
 --##in Hive

 insert into table vbajaj.sales select *  from (select 2,201.01)a; 
 
 ----#hive
 
 select * from  vbajaj.sales;
 
 --##Check hdfs in shell (new terminal)
 
  hdfs dfs -ls /user/hive/warehouse/vbajaj.db/sales/
 
 --## DROP TABLE
 
 drop table vbajaj.sales
 
 
 
  --##Check hdfs in shell (new terminal)
 
