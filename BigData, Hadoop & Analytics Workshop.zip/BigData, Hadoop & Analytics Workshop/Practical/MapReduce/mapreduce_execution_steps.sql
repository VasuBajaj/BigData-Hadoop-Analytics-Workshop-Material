
### Cloudera Proprietary
## Vasu Bajaj
##Date: 15/07/2018



 sudo su hdfs
 hadoop fs -mkdir /user/cloudera
 hadoop fs -chown cloudera /user/cloudera
 exit
 sudo su cloudera
 hadoop fs -mkdir /user/cloudera/wordcount /user/cloudera/wordcount/input 

 echo "Hadoop is an elephant" > file0
 echo "Hadoop is as yellow as can be" > file1
 echo "Oh what a yellow fellow is Hadoop" > file2
 
 hadoop fs -put file* /user/cloudera/wordcount/input 

 mkdir -p build
javac -cp /usr/lib/hadoop/*:/usr/lib/hadoop-mapreduce/* WordCount.java -d build -Xlint 

 mkdir -p build
 javac -cp /opt/cloudera/parcels/CDH/lib/hadoop/*:/opt/cloudera/parcels/CDH/lib/hadoop-mapreduce/* \ WordCount.java -d build -Xlint
	 
jar -cvf wordcount.jar -C build/ . 

hadoop jar wordcount.jar org.myorg.WordCount /user/cloudera/wordcount/input /user/cloudera/wordcount/output

hadoop fs -cat /user/cloudera/wordcount/output/*

###to run again

hadoop fs -rm -r /user/cloudera/wordcount/output 