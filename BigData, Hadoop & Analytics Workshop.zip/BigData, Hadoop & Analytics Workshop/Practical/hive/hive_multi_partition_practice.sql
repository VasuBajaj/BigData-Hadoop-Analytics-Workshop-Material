
CREATE TABLE random (amount FLOAT)
PARTITIONED BY (month INT , date int )
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n' 
STORED AS TEXTFILE;

set hive.exec.dynamic.partition.mode=nonstrict;


insert into table vbajaj.random partition(month, date)
select * from (select 1110, 201807, 20180701)a;