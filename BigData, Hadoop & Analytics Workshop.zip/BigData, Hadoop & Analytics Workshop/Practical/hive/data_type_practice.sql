

Date
timestamp

int 
bigint
decimal
float
double
tinyint


char
varchar
string


create table hadoop.citizen_info(
aadhar_id String,
Name String,
Address String,
Date_of_Birth Date,
Gender String)
partitioned by (year int)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n';

set hive.exec.dynamic.partition.mode=nonstrict;

insert into table hadoop.citizen_info partition(year)
select * from (select '123ddgggggdd', 'Hadoop User', 'IN', '2010-08-01','M', 2010)a;

insert into table hadoop.citizen_info partition(year)
select * from (select 'abc1234hjg', 'Hadoop User 2', 'IN', current_date(),'M', 2010)a;











