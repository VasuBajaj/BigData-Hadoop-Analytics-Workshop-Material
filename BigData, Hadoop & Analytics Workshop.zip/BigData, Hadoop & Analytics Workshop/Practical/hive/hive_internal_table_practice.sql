CREATE  TABLE hadoop.Sales1 (
sale_id INT, 
amount FLOAT)
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
LINES TERMINATED BY '\n' ;


--##shows the table definition
desc hadoop.sales1;

show create table vbajaj.sales1;

----##insert data

 insert into table hadoop.sales1 select *  from (select 1,111.01)a;


 insert into table vbajaj.sales1 select *  from (select 2,201.01)a; 
 
 ----#hive
 
 select * from  vbajaj.sales1;
 
 #hdfs
 
