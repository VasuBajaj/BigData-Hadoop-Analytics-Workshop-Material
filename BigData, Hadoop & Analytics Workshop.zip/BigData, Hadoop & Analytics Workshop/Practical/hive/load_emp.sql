create table hadoop.emp(

emp_id int,
emp_name string)
Row format delimited
fields terminated by ','
lines terminated by '\n';


insert into table hadoop.emp select * from(select 1,'hadoop')a;

